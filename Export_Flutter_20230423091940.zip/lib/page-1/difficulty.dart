import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // difficultyPsv (20:2)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupsnfrXz8 (Wodk56N9uwF9RicuVBSnfr)
              padding: EdgeInsets.fromLTRB(172*fem, 444*fem, 172*fem, 78*fem),
              width: double.infinity,
              height: 561*fem,
              decoration: BoxDecoration (
                image: DecorationImage (
                  fit: BoxFit.cover,
                  image: AssetImage (
                    'assets/page-1/images/ellipse-2-rqN.png',
                  ),
                ),
              ),
              child: Text(
                'Difficulty Level',
                style: SafeGoogleFont (
                  'Itim',
                  fontSize: 32*ffem,
                  fontWeight: FontWeight.w400,
                  height: 1.2*ffem/fem,
                  color: Color(0xffffffff),
                ),
              ),
            ),
            Container(
              // autogrouppji4BHz (WodmW3yvYz14Nv7ry7pJi4)
              padding: EdgeInsets.fromLTRB(26*fem, 128*fem, 25*fem, 211*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupf6re7hS (WodkDvSmzaTWKUpVLrf6Re)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 70*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Container(
                          // autogrouphhfeeSU (WodkZzhfPAj2JydcpzHHFE)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 5*fem),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // image1ab2 (20:22)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 6.95*fem),
                                width: 50*fem,
                                height: 52.05*fem,
                                child: Image.asset(
                                  'assets/page-1/images/image-1.png',
                                  fit: BoxFit.cover,
                                ),
                              ),
                              Container(
                                // easyJ1E (20:23)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4*fem, 17*fem),
                                child: Text(
                                  'easy',
                                  style: SafeGoogleFont (
                                    'Itim',
                                    fontSize: 24*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.2*ffem/fem,
                                    color: Color(0xb2000000),
                                  ),
                                ),
                              ),
                              Container(
                                // image4oya (20:35)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4*fem, 0*fem),
                                width: 20*fem,
                                height: 20*fem,
                                child: Image.asset(
                                  'assets/page-1/images/image-4.png',
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ],
                          ),
                        ),
                        ClipRect(
                          // line2jMS (20:24)
                          child: BackdropFilter(
                            filter: ImageFilter.blur (
                              sigmaX: 2*fem,
                              sigmaY: 2*fem,
                            ),
                            child: Container(
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 19*fem, 0*fem),
                              width: 1*fem,
                              height: 163*fem,
                              decoration: BoxDecoration (
                                color: Color(0xff000000),
                              ),
                            ),
                          ),
                        ),
                        Container(
                          // autogroupanxg144 (WodkiExvUbdc3rDRDranxg)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 32*fem, 5*fem),
                          width: 113*fem,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // autogroupwvjc7sn (Wodkq9w52ghGJ7fzr1wvJC)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 7*fem),
                                width: double.infinity,
                                height: 131*fem,
                                child: Stack(
                                  children: [
                                    Positioned(
                                      // image2rKa (20:26)
                                      left: 7*fem,
                                      top: 0*fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 100*fem,
                                          height: 100*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/image-2.png',
                                            fit: BoxFit.cover,
                                          ),
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      // mediumNHv (20:27)
                                      left: 0*fem,
                                      top: 92*fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 113*fem,
                                          height: 39*fem,
                                          child: Text(
                                            'medium',
                                            style: SafeGoogleFont (
                                              'Itim',
                                              fontSize: 32*ffem,
                                              fontWeight: FontWeight.w400,
                                              height: 1.2*ffem/fem,
                                              color: Color(0xff000000),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // autogroup5sz84Ak (WodktuKpoLNyzhDBPW5sz8)
                                margin: EdgeInsets.fromLTRB(48*fem, 0*fem, 45*fem, 0*fem),
                                width: double.infinity,
                                decoration: BoxDecoration (
                                  image: DecorationImage (
                                    image: AssetImage (
                                      'assets/page-1/images/image-7-bg.png',
                                    ),
                                  ),
                                ),
                                child: Center(
                                  // image8yYc (20:41)
                                  child: SizedBox(
                                    width: 20*fem,
                                    height: 20*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/image-8.png',
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        ClipRect(
                          // line3uhA (20:28)
                          child: BackdropFilter(
                            filter: ImageFilter.blur (
                              sigmaX: 2*fem,
                              sigmaY: 2*fem,
                            ),
                            child: Container(
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 27*fem, 0*fem),
                              width: 1*fem,
                              height: 163*fem,
                              decoration: BoxDecoration (
                                color: Color(0xff000000),
                              ),
                            ),
                          ),
                        ),
                        Container(
                          // autogroup8cmwcba (Wodm24nZCoHh2CWEnJ8CmW)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 5*fem),
                          width: 50*fem,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // image3XyS (20:30)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 9*fem),
                                width: 50*fem,
                                height: 50*fem,
                                child: Image.asset(
                                  'assets/page-1/images/image-3.png',
                                  fit: BoxFit.cover,
                                ),
                              ),
                              Container(
                                // hardGRE (20:31)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 17*fem),
                                child: Text(
                                  'hard',
                                  style: SafeGoogleFont (
                                    'Itim',
                                    fontSize: 24*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.2*ffem/fem,
                                    color: Color(0xb2000000),
                                  ),
                                ),
                              ),
                              Container(
                                // autogroups9rrneU (Wodm7UoCedH4b2wwnfS9Rr)
                                margin: EdgeInsets.fromLTRB(15*fem, 0*fem, 15*fem, 0*fem),
                                width: double.infinity,
                                decoration: BoxDecoration (
                                  image: DecorationImage (
                                    fit: BoxFit.cover,
                                    image: AssetImage (
                                      'assets/page-1/images/image-5-bg.png',
                                    ),
                                  ),
                                ),
                                child: Center(
                                  // image6Jsi (20:38)
                                  child: SizedBox(
                                    width: 20*fem,
                                    height: 20*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/image-6.png',
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // frame16eAt (20:165)
                    margin: EdgeInsets.fromLTRB(66*fem, 0*fem, 78*fem, 0*fem),
                    padding: EdgeInsets.fromLTRB(42*fem, 0*fem, 42*fem, 0*fem),
                    width: double.infinity,
                    height: 41*fem,
                    decoration: BoxDecoration (
                      color: Color(0xff205a9e),
                      borderRadius: BorderRadius.circular(10*fem),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                    child: Text(
                      'select',
                      style: SafeGoogleFont (
                        'Itim',
                        fontSize: 32*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.2*ffem/fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}