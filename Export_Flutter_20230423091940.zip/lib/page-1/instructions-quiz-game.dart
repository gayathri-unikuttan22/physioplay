import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // instructionsquizgamemWx (20:67)
        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 73*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupqikitLg (Wodva3NVaq6xE4ZhpCQiKi)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 501*fem),
              padding: EdgeInsets.fromLTRB(191*fem, 441*fem, 191*fem, 81*fem),
              width: double.infinity,
              height: 561*fem,
              decoration: BoxDecoration (
                image: DecorationImage (
                  fit: BoxFit.cover,
                  image: AssetImage (
                    'assets/page-1/images/ellipse-2-njr.png',
                  ),
                ),
              ),
              child: Text(
                'Instructions',
                style: SafeGoogleFont (
                  'Itim',
                  fontSize: 32*ffem,
                  fontWeight: FontWeight.w400,
                  height: 1.2*ffem/fem,
                  color: Color(0xffffffff),
                ),
              ),
            ),
            Container(
              // frame138Vv (35:3)
              margin: EdgeInsets.fromLTRB(112*fem, 0*fem, 111*fem, 0*fem),
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: double.infinity,
                  height: 39*fem,
                  decoration: BoxDecoration (
                    color: Color(0xff205a9e),
                    borderRadius: BorderRadius.circular(10*fem),
                  ),
                  child: Center(
                    child: Text(
                      'start',
                      style: SafeGoogleFont (
                        'Itim',
                        fontSize: 32*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.2*ffem/fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}