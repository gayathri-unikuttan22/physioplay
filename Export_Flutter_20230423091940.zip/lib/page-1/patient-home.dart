import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // patienthome3r8 (54:6)
        width: double.infinity,
        height: 800*fem,
        decoration: BoxDecoration (
          gradient: LinearGradient (
            begin: Alignment(0.397, -0.059),
            end: Alignment(0.633, 1.049),
            colors: <Color>[Color(0xff063f82), Color(0x9366c41d)],
            stops: <double>[0, 1],
          ),
        ),
        child: Stack(
          children: [
            Positioned(
              // autogroupvud68sa (WodrjjbFC55yeAcQrxVUd6)
              left: 10*fem,
              top: 22*fem,
              child: Container(
                width: 325*fem,
                height: 30*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // image13GD6 (54:21)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 265*fem, 0*fem),
                      width: 30*fem,
                      height: 30*fem,
                      child: Image.asset(
                        'assets/page-1/images/image-13-UMn.png',
                        fit: BoxFit.cover,
                      ),
                    ),
                    Container(
                      // image10PHi (54:7)
                      width: 30*fem,
                      height: 30*fem,
                      child: Image.asset(
                        'assets/page-1/images/image-10-44g.png',
                        fit: BoxFit.cover,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // ellipse4LTr (54:8)
              left: 23*fem,
              top: 67*fem,
              child: Align(
                child: SizedBox(
                  width: 100*fem,
                  height: 100*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(50*fem),
                      image: DecorationImage (
                        fit: BoxFit.cover,
                        image: AssetImage (
                          'assets/page-1/images/ellipse-4-bg-RGk.png',
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // patientnameEJL (54:9)
              left: 23*fem,
              top: 174*fem,
              child: Align(
                child: SizedBox(
                  width: 115*fem,
                  height: 24*fem,
                  child: Text(
                    'patient name',
                    style: SafeGoogleFont (
                      'Itim',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ageKqa (54:10)
              left: 23*fem,
              top: 198*fem,
              child: Align(
                child: SizedBox(
                  width: 31*fem,
                  height: 24*fem,
                  child: Text(
                    'age',
                    style: SafeGoogleFont (
                      'Itim',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // frame17ESk (54:11)
              left: 23*fem,
              top: 284*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(51*fem, 14*fem, 32*fem, 10*fem),
                width: 312*fem,
                height: 67*fem,
                decoration: BoxDecoration (
                  color: Color(0xffffffff),
                  borderRadius: BorderRadius.circular(10*fem),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // gamesWv4 (54:15)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 34*fem, 4*fem),
                      child: Text(
                        'games\n',
                        style: SafeGoogleFont (
                          'Itim',
                          fontSize: 32*ffem,
                          fontWeight: FontWeight.w400,
                          height: 1.2*ffem/fem,
                          color: Color(0xff000000),
                        ),
                      ),
                    ),
                    Container(
                      // line4qBe (54:13)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 25*fem, 0*fem),
                      width: 1*fem,
                      height: 43*fem,
                      decoration: BoxDecoration (
                        color: Color(0xff000000),
                      ),
                    ),
                    Container(
                      // progressAUp (54:14)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                      child: Text(
                        'PROGRESS',
                        style: SafeGoogleFont (
                          'Itim',
                          fontSize: 16*ffem,
                          fontWeight: FontWeight.w400,
                          height: 1.2*ffem/fem,
                          color: Color(0xff000000),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // recentlyplayedgxx (54:16)
              left: 22*fem,
              top: 229*fem,
              child: Align(
                child: SizedBox(
                  width: 132*fem,
                  height: 24*fem,
                  child: Text(
                    'recently played',
                    style: SafeGoogleFont (
                      'Itim',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // frame31YEU (54:41)
              left: 25*fem,
              top: 406*fem,
              child: Container(
                width: 312*fem,
                height: 295*fem,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // autogrouprm4cSqe (WodsGoXp3EZbxACcCurM4c)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 55*fem),
                      width: double.infinity,
                      height: 120*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogroup9rqaNUQ (WodsTt3gnGPPs4vVzH9RqA)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 34*fem, 0*fem),
                            padding: EdgeInsets.fromLTRB(13*fem, 7*fem, 6*fem, 10*fem),
                            width: 139*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(10*fem),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // autogroupyataGJt (WodsYiEyEt4zH1kRXqYaTA)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 15*fem),
                                  width: double.infinity,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // ellipse81GU (54:22)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 30*fem, 0*fem),
                                        width: 70*fem,
                                        height: 70*fem,
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(35*fem),
                                          border: Border.all(color: Color(0xff000000)),
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/ellipse-8-bg.png',
                                            ),
                                          ),
                                          boxShadow: [
                                            BoxShadow(
                                              color: Color(0x3f000000),
                                              offset: Offset(0*fem, 4*fem),
                                              blurRadius: 2*fem,
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        // image37GTJ (54:23)
                                        width: 20*fem,
                                        height: 20*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/image-37.png',
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // flappybirdbkU (54:24)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 50*fem, 0*fem),
                                  child: Text(
                                    'flappy bird\n',
                                    style: SafeGoogleFont (
                                      'Itim',
                                      fontSize: 15*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.2*ffem/fem,
                                      color: Color(0xff000000),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogroupsgwctzU (WodshhyytSWiMbqfEbsgWC)
                            padding: EdgeInsets.fromLTRB(17*fem, 7*fem, 2*fem, 10*fem),
                            width: 139*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(10*fem),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // autogroupgqdzbtt (WodsmhsKWU3UqRDKYigqdz)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 15*fem),
                                  width: double.infinity,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // ellipse10jkC (54:35)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 30*fem, 0*fem),
                                        width: 70*fem,
                                        height: 70*fem,
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(35*fem),
                                          border: Border.all(color: Color(0xff000000)),
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/ellipse-10-bg.png',
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // image38e6U (54:25)
                                        width: 20*fem,
                                        height: 20*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/image-38.png',
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // balloonpopperaF2 (54:36)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 24*fem, 0*fem),
                                  child: Text(
                                    'balloon popper',
                                    style: SafeGoogleFont (
                                      'Itim',
                                      fontSize: 15*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.2*ffem/fem,
                                      color: Color(0xff000000),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // autogroupsrz66DN (Wodt52hnXv1UFHqBZtsrZ6)
                      width: double.infinity,
                      height: 120*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogroupyn1eEqN (WodtDh823dzTxE97aUyN1e)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 34*fem, 0*fem),
                            padding: EdgeInsets.fromLTRB(13*fem, 7*fem, 6*fem, 18*fem),
                            width: 139*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(10*fem),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // autogroupkvrx8fr (WodtKmnDm8uJGN9RyCkVrx)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 7*fem),
                                  width: double.infinity,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // ellipse9fvg (54:33)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 30*fem, 0*fem),
                                        width: 70*fem,
                                        height: 70*fem,
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(35*fem),
                                          border: Border.all(color: Color(0xff000000)),
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/ellipse-9-bg.png',
                                            ),
                                          ),
                                          boxShadow: [
                                            BoxShadow(
                                              color: Color(0x3f000000),
                                              offset: Offset(0*fem, 4*fem),
                                              blurRadius: 2*fem,
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        // image40w7W (54:27)
                                        width: 20*fem,
                                        height: 20*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/image-40.png',
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // fruitcollectionfJQ (54:34)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 24*fem, 0*fem),
                                  child: Text(
                                    'fruit collection\n',
                                    style: SafeGoogleFont (
                                      'Itim',
                                      fontSize: 15*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.2*ffem/fem,
                                      color: Color(0xff000000),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogrouphbdzBGk (WodtXBcse1BpYvedSkHBDz)
                            padding: EdgeInsets.fromLTRB(17*fem, 7*fem, 2*fem, 18*fem),
                            width: 139*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(10*fem),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // autogroup6lmntwr (WodtbBWDG2ib2k2Hks6LMn)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 7*fem),
                                  width: double.infinity,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // image41duS (54:39)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 30*fem, 0*fem),
                                        width: 70*fem,
                                        height: 70*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/image-41.png',
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                      Container(
                                        // image39mVr (54:26)
                                        width: 20*fem,
                                        height: 20*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/image-39.png',
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // shooteriR6 (54:40)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 51*fem, 0*fem),
                                  child: Text(
                                    'shooter',
                                    style: SafeGoogleFont (
                                      'Itim',
                                      fontSize: 15*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.2*ffem/fem,
                                      color: Color(0xff000000),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}