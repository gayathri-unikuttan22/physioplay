import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // quizgamehomebrY (20:49)
        width: double.infinity,
        height: 800*fem,
        decoration: BoxDecoration (
          gradient: LinearGradient (
            begin: Alignment(0.397, -0.059),
            end: Alignment(0.633, 1.049),
            colors: <Color>[Color(0xff063f82), Color(0x9366c41d)],
            stops: <double>[0, 1],
          ),
        ),
        child: Stack(
          children: [
            Positioned(
              // autogroup9opu19a (WodpuNUop5TExxVGy89opU)
              left: 10*fem,
              top: 37*fem,
              child: Container(
                width: 322*fem,
                height: 30*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      // image11JuN (20:91)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 267*fem, 0*fem),
                      child: TextButton(
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          width: 25*fem,
                          height: 25*fem,
                          child: Image.asset(
                            'assets/page-1/images/image-11.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ),
                    Container(
                      // image10or8 (20:87)
                      width: 30*fem,
                      height: 30*fem,
                      child: Image.asset(
                        'assets/page-1/images/image-10.png',
                        fit: BoxFit.cover,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // ellipse4ZaQ (20:89)
              left: 23*fem,
              top: 67*fem,
              child: Align(
                child: SizedBox(
                  width: 100*fem,
                  height: 100*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(50*fem),
                      image: DecorationImage (
                        fit: BoxFit.cover,
                        image: AssetImage (
                          'assets/page-1/images/ellipse-4-bg-wXE.png',
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // patientnameTQt (20:92)
              left: 23*fem,
              top: 174*fem,
              child: Align(
                child: SizedBox(
                  width: 115*fem,
                  height: 24*fem,
                  child: Text(
                    'patient name',
                    style: SafeGoogleFont (
                      'Itim',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // agejNQ (20:93)
              left: 23*fem,
              top: 198*fem,
              child: Align(
                child: SizedBox(
                  width: 31*fem,
                  height: 24*fem,
                  child: Text(
                    'age',
                    style: SafeGoogleFont (
                      'Itim',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // frame17qAY (20:166)
              left: 23*fem,
              top: 284*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(65*fem, 14*fem, 32*fem, 10*fem),
                width: 312*fem,
                height: 67*fem,
                decoration: BoxDecoration (
                  color: Color(0xffffffff),
                  borderRadius: BorderRadius.circular(10*fem),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // quiz784 (20:95)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 39*fem, 4*fem),
                      child: Text(
                        'QUIZ',
                        style: SafeGoogleFont (
                          'Itim',
                          fontSize: 32*ffem,
                          fontWeight: FontWeight.w400,
                          height: 1.2*ffem/fem,
                          color: Color(0xff000000),
                        ),
                      ),
                    ),
                    Container(
                      // line4ds6 (20:96)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 25*fem, 0*fem),
                      width: 1*fem,
                      height: 43*fem,
                      decoration: BoxDecoration (
                        color: Color(0xff000000),
                      ),
                    ),
                    Container(
                      // progressyRA (20:97)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                      child: Text(
                        'PROGRESS',
                        style: SafeGoogleFont (
                          'Itim',
                          fontSize: 16*ffem,
                          fontWeight: FontWeight.w400,
                          height: 1.2*ffem/fem,
                          color: Color(0xff000000),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // frame10Usi (20:159)
              left: 88*fem,
              top: 536*fem,
              child: Container(
                width: 180*fem,
                height: 52*fem,
                decoration: BoxDecoration (
                  color: Color(0xffffffff),
                  borderRadius: BorderRadius.circular(10*fem),
                ),
                child: Center(
                  child: Text(
                    'RESTART',
                    style: SafeGoogleFont (
                      'Itim',
                      fontSize: 16*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // frame9Ycg (20:158)
              left: 88*fem,
              top: 426*fem,
              child: Container(
                width: 180*fem,
                height: 52*fem,
                decoration: BoxDecoration (
                  color: Color(0xffffffff),
                  borderRadius: BorderRadius.circular(10*fem),
                ),
                child: Center(
                  child: Text(
                    'NEW GAME',
                    style: SafeGoogleFont (
                      'Itim',
                      fontSize: 16*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // recentlyplayed96g (20:136)
              left: 22*fem,
              top: 229*fem,
              child: Align(
                child: SizedBox(
                  width: 132*fem,
                  height: 24*fem,
                  child: Text(
                    'recently played',
                    style: SafeGoogleFont (
                      'Itim',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}