import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // quizQ4p (7:3)
        padding: EdgeInsets.fromLTRB(26*fem, 8*fem, 36*fem, 95*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          gradient: LinearGradient (
            begin: Alignment(0, -1),
            end: Alignment(1, 1),
            colors: <Color>[Color(0xff063f81), Color(0xdd66c31d)],
            stops: <double>[0.419, 0.994],
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroup2xck4QG (WodnSMkmaB89E6Sast2Xck)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
              width: double.infinity,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Container(
                    // autogroupbehnPBe (WodnZgstYZGDSRdJ7mBehN)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 11*fem, 0*fem),
                    width: 49*fem,
                    height: 45*fem,
                    child: Stack(
                      children: [
                        Positioned(
                          // frame5teC (18:21)
                          left: 0*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 49*fem,
                              height: 45*fem,
                              child: Image.asset(
                                'assets/page-1/images/frame-5.png',
                                width: 49*fem,
                                height: 45*fem,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // Cet (18:24)
                          left: 20*fem,
                          top: 17*fem,
                          child: Align(
                            child: SizedBox(
                              width: 10*fem,
                              height: 20*fem,
                              child: Text(
                                '4',
                                style: SafeGoogleFont (
                                  'Itim',
                                  fontSize: 16*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.2*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // frame6hbe (18:25)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 14*fem, 3*fem),
                    width: 49*fem,
                    height: 43*fem,
                    decoration: BoxDecoration (
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                    child: Stack(
                      children: [
                        Positioned(
                          // ellipse5PzG (18:26)
                          left: 0*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 41*fem,
                              height: 43*fem,
                              child: Image.asset(
                                'assets/page-1/images/ellipse-5-23z.png',
                                width: 41*fem,
                                height: 43*fem,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // X4t (20:19)
                          left: 14*fem,
                          top: 6*fem,
                          child: Align(
                            child: SizedBox(
                              width: 13*fem,
                              height: 29*fem,
                              child: Text(
                                '5',
                                style: SafeGoogleFont (
                                  'Itim',
                                  fontSize: 24*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.2*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // frame2Rg4 (18:11)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 18*fem, 2*fem),
                    width: 58*fem,
                    height: 57*fem,
                    decoration: BoxDecoration (
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                    child: Stack(
                      children: [
                        Positioned(
                          // ellipse5jgk (18:8)
                          left: 0*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 55*fem,
                              height: 57*fem,
                              child: Image.asset(
                                'assets/page-1/images/ellipse-5-msn.png',
                                width: 55*fem,
                                height: 57*fem,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // sHA (18:10)
                          left: 18.3076171875*fem,
                          top: 8.7004394531*fem,
                          child: Align(
                            child: SizedBox(
                              width: 17*fem,
                              height: 39*fem,
                              child: Text(
                                '6',
                                style: SafeGoogleFont (
                                  'Itim',
                                  fontSize: 32*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.2*ffem/fem,
                                  color: Color(0xff205a9e),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // frame7Nji (20:42)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 3*fem),
                    width: 49*fem,
                    height: 43*fem,
                    decoration: BoxDecoration (
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                    child: Stack(
                      children: [
                        Positioned(
                          // ellipse569v (20:43)
                          left: 0*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 41*fem,
                              height: 43*fem,
                              child: Image.asset(
                                'assets/page-1/images/ellipse-5.png',
                                width: 41*fem,
                                height: 43*fem,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // nYY (20:45)
                          left: 15*fem,
                          top: 6*fem,
                          child: Align(
                            child: SizedBox(
                              width: 12*fem,
                              height: 29*fem,
                              child: Text(
                                '7',
                                style: SafeGoogleFont (
                                  'Itim',
                                  fontSize: 24*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.2*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // frame8WDe (20:46)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                    width: 49*fem,
                    height: 45*fem,
                    decoration: BoxDecoration (
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                    child: Stack(
                      children: [
                        Positioned(
                          // ellipse5RbW (20:47)
                          left: 10*fem,
                          top: 12*fem,
                          child: Align(
                            child: SizedBox(
                              width: 35*fem,
                              height: 33*fem,
                              child: Image.asset(
                                'assets/page-1/images/ellipse-5-MMz.png',
                                width: 35*fem,
                                height: 33*fem,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // Kwn (20:48)
                          left: 23*fem,
                          top: 19*fem,
                          child: Align(
                            child: SizedBox(
                              width: 9*fem,
                              height: 20*fem,
                              child: Text(
                                '8',
                                style: SafeGoogleFont (
                                  'Itim',
                                  fontSize: 16*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.2*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroup7ugqqQL (Wodnqvupt3EL8vxR8s7UgQ)
              margin: EdgeInsets.fromLTRB(21*fem, 0*fem, 0*fem, 46*fem),
              width: 263*fem,
              height: 545*fem,
              child: Stack(
                children: [
                  Positioned(
                    // group2mHz (18:3)
                    left: 0*fem,
                    top: 50*fem,
                    child: Container(
                      width: 263*fem,
                      height: 495*fem,
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(10*fem),
                      ),
                      child: Container(
                        // group1Vjn (18:2)
                        padding: EdgeInsets.fromLTRB(8*fem, 20*fem, 15*fem, 29*fem),
                        width: double.infinity,
                        height: double.infinity,
                        decoration: BoxDecoration (
                          color: Color(0xffffffff),
                          borderRadius: BorderRadius.circular(10*fem),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // image9yex (20:51)
                              margin: EdgeInsets.fromLTRB(220*fem, 0*fem, 0*fem, 29*fem),
                              width: 20*fem,
                              height: 20*fem,
                              child: Image.asset(
                                'assets/page-1/images/image-9.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                            Container(
                              // question6107FN (9:121)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 116*fem, 18*fem),
                              child: Text(
                                'Question 6/10',
                                style: SafeGoogleFont (
                                  'Itim',
                                  fontSize: 20*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.2*ffem/fem,
                                  color: Color(0xff205a9e),
                                ),
                              ),
                            ),
                            Container(
                              // cT2 (9:112)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 13*fem, 19*fem),
                              child: Text(
                                '2+2=___',
                                style: SafeGoogleFont (
                                  'Itim',
                                  fontSize: 32*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.2*ffem/fem,
                                  color: Color(0xff205a9e),
                                ),
                              ),
                            ),
                            ImageFiltered(
                              // line1LP2 (18:6)
                              imageFilter: ImageFilter.blur (
                                sigmaX: 2*fem,
                                sigmaY: 2*fem,
                              ),
                              child: Container(
                                margin: EdgeInsets.fromLTRB(38*fem, 0*fem, 36*fem, 39*fem),
                                width: double.infinity,
                                height: 1*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                            Container(
                              // autogroupxff6qag (WodoCRKggvaG6VVgEiXfF6)
                              margin: EdgeInsets.fromLTRB(38*fem, 0*fem, 36*fem, 18*fem),
                              width: double.infinity,
                              height: 39*fem,
                              child: Stack(
                                children: [
                                  Positioned(
                                    // rectangle9Acx (9:107)
                                    left: 0*fem,
                                    top: 6*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 166*fem,
                                        height: 31*fem,
                                        child: Container(
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(10*fem),
                                            color: Color(0xffd9d9d9),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // rectangle10FuJ (9:108)
                                    left: 0*fem,
                                    top: 6*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 166*fem,
                                        height: 31*fem,
                                        child: Container(
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(10*fem),
                                            color: Color(0xffd9d9d9),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // rectangle8Nj2 (9:106)
                                    left: 0*fem,
                                    top: 5*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 166*fem,
                                        height: 31*fem,
                                        child: Container(
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(10*fem),
                                            color: Color(0xff205a9e),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // tBa (9:115)
                                    left: 73*fem,
                                    top: 0*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 20*fem,
                                        height: 39*fem,
                                        child: Text(
                                          '4',
                                          style: SafeGoogleFont (
                                            'Itim',
                                            fontSize: 32*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.2*ffem/fem,
                                            color: Color(0xffffffff),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              // autogroupoacxzkQ (WodoKv7CEDwhVea3Kgoacx)
                              margin: EdgeInsets.fromLTRB(38*fem, 0*fem, 36*fem, 17*fem),
                              width: double.infinity,
                              height: 39*fem,
                              child: Stack(
                                children: [
                                  Positioned(
                                    // rectangle8XkL (9:109)
                                    left: 0*fem,
                                    top: 4*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 166*fem,
                                        height: 31*fem,
                                        child: Container(
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(10*fem),
                                            color: Color(0xff205a9e),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // Eek (9:116)
                                    left: 73*fem,
                                    top: 0*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 17*fem,
                                        height: 39*fem,
                                        child: Text(
                                          '6',
                                          style: SafeGoogleFont (
                                            'Itim',
                                            fontSize: 32*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.2*ffem/fem,
                                            color: Color(0xffffffff),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              // autogroupsvgpk7J (WodoQzo4YDULgqESdssvgp)
                              margin: EdgeInsets.fromLTRB(38*fem, 0*fem, 36*fem, 13*fem),
                              width: double.infinity,
                              height: 39*fem,
                              child: Stack(
                                children: [
                                  Positioned(
                                    // rectangle11TnQ (9:110)
                                    left: 0*fem,
                                    top: 2*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 166*fem,
                                        height: 31*fem,
                                        child: Container(
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(10*fem),
                                            color: Color(0xff205a9e),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // N8g (9:117)
                                    left: 74*fem,
                                    top: 0*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 16*fem,
                                        height: 39*fem,
                                        child: Text(
                                          '7',
                                          style: SafeGoogleFont (
                                            'Itim',
                                            fontSize: 32*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.2*ffem/fem,
                                            color: Color(0xffffffff),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              // autogroupxgkgsr8 (WodoW5UvrCzyt1tqx4xGkg)
                              margin: EdgeInsets.fromLTRB(38*fem, 0*fem, 36*fem, 5*fem),
                              width: double.infinity,
                              height: 39*fem,
                              child: Stack(
                                children: [
                                  Positioned(
                                    // rectangle12cHv (9:111)
                                    left: 0*fem,
                                    top: 4*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 166*fem,
                                        height: 31*fem,
                                        child: Container(
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(10*fem),
                                            color: Color(0xff205a9e),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // WPJ (9:119)
                                    left: 74*fem,
                                    top: 0*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 18*fem,
                                        height: 39*fem,
                                        child: Text(
                                          '3',
                                          style: SafeGoogleFont (
                                            'Itim',
                                            fontSize: 32*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.2*ffem/fem,
                                            color: Color(0xffffffff),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              // autogroup4da8ae4 (WodobueYiL4mQv4gaA4DA8)
                              width: double.infinity,
                              height: 48*fem,
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // autogrouprwm2vT2 (WodoijnVyxWk4maSGmrwM2)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 154*fem, 0*fem),
                                    width: 43*fem,
                                    height: double.infinity,
                                    decoration: BoxDecoration (
                                      image: DecorationImage (
                                        fit: BoxFit.cover,
                                        image: AssetImage (
                                          'assets/page-1/images/ellipse-4.png',
                                        ),
                                      ),
                                    ),
                                    child: Center(
                                      child: Text(
                                        'help',
                                        style: SafeGoogleFont (
                                          'Itim',
                                          fontSize: 20*ffem,
                                          fontWeight: FontWeight.w400,
                                          height: 1.2*ffem/fem,
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // autogroupr5tebZA (WodopQHjHAMAQqrd3mr5TE)
                                    width: 43*fem,
                                    height: double.infinity,
                                    decoration: BoxDecoration (
                                      image: DecorationImage (
                                        fit: BoxFit.cover,
                                        image: AssetImage (
                                          'assets/page-1/images/ellipse-3.png',
                                        ),
                                      ),
                                    ),
                                    child: Center(
                                      child: Text(
                                        '60',
                                        style: SafeGoogleFont (
                                          'Itim',
                                          fontSize: 32*ffem,
                                          fontWeight: FontWeight.w400,
                                          height: 1.2*ffem/fem,
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // ellipse46kp (9:120)
                    left: 76*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 100*fem,
                        height: 100*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(50*fem),
                            image: DecorationImage (
                              fit: BoxFit.cover,
                              image: AssetImage (
                                'assets/page-1/images/ellipse-4-bg-byr.png',
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // frame18avt (20:167)
              margin: EdgeInsets.fromLTRB(71*fem, 0*fem, 74*fem, 0*fem),
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: double.infinity,
                  height: 39*fem,
                  child: Stack(
                    children: [
                      Positioned(
                        // rectangle7i1W (8:92)
                        left: 0*fem,
                        top: 2*fem,
                        child: Align(
                          child: SizedBox(
                            width: 153*fem,
                            height: 36*fem,
                            child: Container(
                              decoration: BoxDecoration (
                                borderRadius: BorderRadius.circular(10*fem),
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        // nextdeG (9:104)
                        left: 46*fem,
                        top: 0*fem,
                        child: Align(
                          child: SizedBox(
                            width: 62*fem,
                            height: 39*fem,
                            child: Text(
                              'next',
                              style: SafeGoogleFont (
                                'Itim',
                                fontSize: 32*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.2*ffem/fem,
                                color: Color(0xff205a9e),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}