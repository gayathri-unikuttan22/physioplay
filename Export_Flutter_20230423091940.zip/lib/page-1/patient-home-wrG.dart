import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // patienthomercQ (54:61)
        width: double.infinity,
        height: 800*fem,
        decoration: BoxDecoration (
          gradient: LinearGradient (
            begin: Alignment(0.397, -0.059),
            end: Alignment(0.633, 1.049),
            colors: <Color>[Color(0xff063f82), Color(0x9366c41d)],
            stops: <double>[0, 1],
          ),
        ),
        child: Stack(
          children: [
            Positioned(
              // autogroupnatyXyS (WoduW9ywjszkPKDntvNAtY)
              left: 10*fem,
              top: 22*fem,
              child: Container(
                width: 325*fem,
                height: 30*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // image134Cg (54:72)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 265*fem, 0*fem),
                      width: 30*fem,
                      height: 30*fem,
                      child: Image.asset(
                        'assets/page-1/images/image-13-ioa.png',
                        fit: BoxFit.cover,
                      ),
                    ),
                    Container(
                      // image10BHJ (54:62)
                      width: 30*fem,
                      height: 30*fem,
                      child: Image.asset(
                        'assets/page-1/images/image-10-pcY.png',
                        fit: BoxFit.cover,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // ellipse48TS (54:63)
              left: 23*fem,
              top: 67*fem,
              child: Align(
                child: SizedBox(
                  width: 100*fem,
                  height: 100*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(50*fem),
                      image: DecorationImage (
                        fit: BoxFit.cover,
                        image: AssetImage (
                          'assets/page-1/images/ellipse-4-bg.png',
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // patientnameEWU (54:64)
              left: 23*fem,
              top: 174*fem,
              child: Align(
                child: SizedBox(
                  width: 115*fem,
                  height: 24*fem,
                  child: Text(
                    'patient name',
                    style: SafeGoogleFont (
                      'Itim',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ageKXv (54:65)
              left: 23*fem,
              top: 198*fem,
              child: Align(
                child: SizedBox(
                  width: 31*fem,
                  height: 24*fem,
                  child: Text(
                    'age',
                    style: SafeGoogleFont (
                      'Itim',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // recentlyplayedpja (54:71)
              left: 22*fem,
              top: 229*fem,
              child: Align(
                child: SizedBox(
                  width: 132*fem,
                  height: 24*fem,
                  child: Text(
                    'recently played',
                    style: SafeGoogleFont (
                      'Itim',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // frame33um2 (54:91)
              left: 53*fem,
              top: 528*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(18*fem, 7*fem, 18*fem, 11*fem),
                width: 255*fem,
                height: 250*fem,
                decoration: BoxDecoration (
                  color: Color(0xffffffff),
                  borderRadius: BorderRadius.circular(10*fem),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      // activityPgC (54:94)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                      child: Text(
                        'activity ',
                        style: SafeGoogleFont (
                          'Itim',
                          fontSize: 20*ffem,
                          fontWeight: FontWeight.w400,
                          height: 1.2*ffem/fem,
                          color: Color(0xff000000),
                        ),
                      ),
                    ),
                    Container(
                      // image33JYG (54:93)
                      width: 200*fem,
                      height: 200*fem,
                      child: Image.asset(
                        'assets/page-1/images/image-33-Q9n.png',
                        fit: BoxFit.cover,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // autogroupytmr41e (Woduh4qRuzbB7Q42qCYTMr)
              left: 17*fem,
              top: 312*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(8*fem, 5*fem, 0*fem, 39*fem),
                width: 282*fem,
                height: 142*fem,
                decoration: BoxDecoration (
                  color: Color(0xffffffff),
                  borderRadius: BorderRadius.circular(10*fem),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // autogroupvk64k9N (WodusZXwfp7BsRA99kvk64)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 11*fem),
                      width: double.infinity,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // headmovementleftgHv (54:123)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 75*fem, 0*fem),
                            child: Text(
                              'head movement- left\n',
                              style: SafeGoogleFont (
                                'Itim',
                                fontSize: 20*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.2*ffem/fem,
                                color: Color(0xff000000),
                              ),
                            ),
                          ),
                          Container(
                            // image32zJc (54:121)
                            width: 20*fem,
                            height: 20*fem,
                            child: Image.asset(
                              'assets/page-1/images/image-32.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // autogroupvsgu89v (Woduz4M7oc6S9ctbACVsgU)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 37*fem, 0*fem),
                      width: 229*fem,
                      height: 63*fem,
                      child: Stack(
                        children: [
                          Positioned(
                            // done50SwJ (54:126)
                            left: 32*fem,
                            top: 0*fem,
                            child: Align(
                              child: SizedBox(
                                width: 56*fem,
                                height: 20*fem,
                                child: Text(
                                  'done 50\n',
                                  style: SafeGoogleFont (
                                    'Itim',
                                    fontSize: 16*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.2*ffem/fem,
                                    color: Color(0xff000000),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // line18MYU (54:124)
                            left: 137*fem,
                            top: 0*fem,
                            child: Align(
                              child: SizedBox(
                                width: 1*fem,
                                height: 63*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0xff000000),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // line19fp4 (54:125)
                            left: 85*fem,
                            top: 29*fem,
                            child: Align(
                              child: SizedBox(
                                width: 105*fem,
                                height: 1*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0xff000000),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // missed10bhi (54:129)
                            left: 159*fem,
                            top: 0*fem,
                            child: Align(
                              child: SizedBox(
                                width: 70*fem,
                                height: 20*fem,
                                child: Text(
                                  'missed 10',
                                  style: SafeGoogleFont (
                                    'Itim',
                                    fontSize: 16*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.2*ffem/fem,
                                    color: Color(0xff000000),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // totalscore200ptsuiQ (54:130)
                            left: 0*fem,
                            top: 39*fem,
                            child: Align(
                              child: SizedBox(
                                width: 130*fem,
                                height: 20*fem,
                                child: Text(
                                  'total score-200pts',
                                  style: SafeGoogleFont (
                                    'Itim',
                                    fontSize: 16*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.2*ffem/fem,
                                    color: Color(0xff000000),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // image28p4g (54:131)
                            left: 184*fem,
                            top: 43*fem,
                            child: Align(
                              child: SizedBox(
                                width: 20*fem,
                                height: 20*fem,
                                child: Image.asset(
                                  'assets/page-1/images/image-28-jMJ.png',
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // line20L32 (54:133)
              left: 74*fem,
              top: 491*fem,
              child: Align(
                child: SizedBox(
                  width: 198*fem,
                  height: 1*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0x7f000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle474Up (54:134)
              left: 113*fem,
              top: 487*fem,
              child: Align(
                child: SizedBox(
                  width: 78*fem,
                  height: 3*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xff121212),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}