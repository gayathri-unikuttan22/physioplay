import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // doctorspage14Zv (20:138)
        padding: EdgeInsets.fromLTRB(13*fem, 22*fem, 12*fem, 0*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          gradient: LinearGradient (
            begin: Alignment(0.397, -0.059),
            end: Alignment(0.633, 1.049),
            colors: <Color>[Color(0xff063f82), Color(0x9366c41d)],
            stops: <double>[0, 1],
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              // image12L1e (20:154)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
              width: 30*fem,
              height: 30*fem,
              child: Image.asset(
                'assets/page-1/images/image-12.png',
                fit: BoxFit.cover,
              ),
            ),
            Container(
              // autogroup3m36U7r (WodvpT89gDY3sV6eXL3m36)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 6*fem, 55*fem),
              width: double.infinity,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    // frame25zbz (39:99)
                    margin: EdgeInsets.fromLTRB(0*fem, 28*fem, 97*fem, 0*fem),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Container(
                          // image30Y7i (39:84)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 6*fem),
                          width: 100*fem,
                          height: 100*fem,
                          child: Image.asset(
                            'assets/page-1/images/image-30.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                        Text(
                          // doctorsname4rk (39:85)
                          'doctor’s name',
                          style: SafeGoogleFont (
                            'Itim',
                            fontSize: 15*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.2*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // frame23nXr (39:82)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 115*fem),
                    padding: EdgeInsets.fromLTRB(11*fem, 8*fem, 50*fem, 9*fem),
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                      borderRadius: BorderRadius.circular(10*fem),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // image29U9n (39:75)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                          width: 20*fem,
                          height: 20*fem,
                          child: Image.asset(
                            'assets/page-1/images/image-29-z8G.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                        Container(
                          // searchzdv (39:76)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 2*fem),
                          child: Text(
                            'search',
                            style: SafeGoogleFont (
                              'Itim',
                              fontSize: 15*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2*ffem/fem,
                              color: Color(0x7f000000),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupns68i48 (WodvySsAKmymx5BtE6Ns68)
              margin: EdgeInsets.fromLTRB(9*fem, 0*fem, 0*fem, 0*fem),
              width: 326*fem,
              height: 542*fem,
              child: Stack(
                children: [
                  Positioned(
                    // nameEoA (39:129)
                    left: 178*fem,
                    top: 516*fem,
                    child: Align(
                      child: SizedBox(
                        width: 49*fem,
                        height: 24*fem,
                        child: Text(
                          'name',
                          style: SafeGoogleFont (
                            'Itim',
                            fontSize: 20*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.2*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // frame30wxU (49:192)
                    left: 0*fem,
                    top: 0*fem,
                    child: Container(
                      width: 326*fem,
                      height: 542*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogroup2woj5Hz (WodwYM61R2zRK9aFt22WoJ)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 30*fem, 0*fem),
                            width: 128*fem,
                            height: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // autogroupk3axny6 (WodwzLLhxCwQRxW3unK3Ax)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 35*fem),
                                  padding: EdgeInsets.fromLTRB(11*fem, 7*fem, 0*fem, 7*fem),
                                  width: double.infinity,
                                  height: 111*fem,
                                  decoration: BoxDecoration (
                                    color: Color(0xffffffff),
                                    borderRadius: BorderRadius.circular(10*fem),
                                  ),
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // autogroupum6xGtG (Wodx7adde8To3sjwE7um6x)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 27*fem, 0*fem),
                                        width: 70*fem,
                                        height: double.infinity,
                                        child: Stack(
                                          children: [
                                            Positioned(
                                              // ellipse515A (39:103)
                                              left: 0*fem,
                                              top: 0*fem,
                                              child: Align(
                                                child: SizedBox(
                                                  width: 70*fem,
                                                  height: 76*fem,
                                                  child: Image.asset(
                                                    'assets/page-1/images/ellipse-5-A8x.png',
                                                    width: 70*fem,
                                                    height: 76*fem,
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              // nameHYU (39:122)
                                              left: 11*fem,
                                              top: 73*fem,
                                              child: Align(
                                                child: SizedBox(
                                                  width: 49*fem,
                                                  height: 24*fem,
                                                  child: Text(
                                                    'name',
                                                    style: SafeGoogleFont (
                                                      'Itim',
                                                      fontSize: 20*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1.2*ffem/fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        // image9nVE (39:104)
                                        width: 20*fem,
                                        height: 20*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/image-9-yPv.png',
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // autogroupqhb6Kzx (WodxEaRyUg98tZ9LmpqHb6)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 35*fem),
                                  padding: EdgeInsets.fromLTRB(8*fem, 6*fem, 0*fem, 6*fem),
                                  width: double.infinity,
                                  height: 111*fem,
                                  decoration: BoxDecoration (
                                    color: Color(0xffffffff),
                                    borderRadius: BorderRadius.circular(10*fem),
                                  ),
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // autogroupjdje2Pa (WodxLpkZm6HLPX3K1djDje)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 30*fem, 0*fem),
                                        width: 70*fem,
                                        height: 92*fem,
                                        child: Stack(
                                          children: [
                                            Positioned(
                                              // image28Mgk (39:113)
                                              left: 0*fem,
                                              top: 0*fem,
                                              child: Align(
                                                child: SizedBox(
                                                  width: 70*fem,
                                                  height: 70*fem,
                                                  child: Image.asset(
                                                    'assets/page-1/images/image-28-DSg.png',
                                                    fit: BoxFit.cover,
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              // name5Mr (39:123)
                                              left: 8*fem,
                                              top: 68*fem,
                                              child: Align(
                                                child: SizedBox(
                                                  width: 49*fem,
                                                  height: 24*fem,
                                                  child: Text(
                                                    'name',
                                                    style: SafeGoogleFont (
                                                      'Itim',
                                                      fontSize: 20*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1.2*ffem/fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        // image19nn4 (39:111)
                                        width: 20*fem,
                                        height: 20*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/image-19-Uh6.png',
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // autogroupqa96LHn (WodxSevBdDM7vRD9diqA96)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 28*fem),
                                  padding: EdgeInsets.fromLTRB(11*fem, 7*fem, 0*fem, 9*fem),
                                  width: double.infinity,
                                  decoration: BoxDecoration (
                                    color: Color(0xffffffff),
                                    borderRadius: BorderRadius.circular(10*fem),
                                  ),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // autogroupfu6gRa8 (WodxYEbDdxZrg5YWVBFu6g)
                                        width: double.infinity,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // image28ahv (39:116)
                                              margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 27*fem, 0*fem),
                                              width: 70*fem,
                                              height: 70*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/image-28-uMr.png',
                                                fit: BoxFit.cover,
                                              ),
                                            ),
                                            Container(
                                              // image18tTi (39:110)
                                              width: 20*fem,
                                              height: 20*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/image-18.png',
                                                fit: BoxFit.cover,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        // nameEGg (39:124)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 46*fem, 0*fem),
                                        child: Text(
                                          'name',
                                          style: SafeGoogleFont (
                                            'Itim',
                                            fontSize: 20*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.2*ffem/fem,
                                            color: Color(0xff000000),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // autogroupgcba98k (WodxhUpp8trdXuUDxaGCba)
                                  padding: EdgeInsets.fromLTRB(11*fem, 7*fem, 0*fem, 2*fem),
                                  width: double.infinity,
                                  height: 111*fem,
                                  decoration: BoxDecoration (
                                    color: Color(0xffffffff),
                                    borderRadius: BorderRadius.circular(10*fem),
                                  ),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // autogroupyyvlFha (Wodxn9Mi2bJrm2QVf3YYvL)
                                        width: double.infinity,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // image31oUC (39:121)
                                              margin: EdgeInsets.fromLTRB(0*fem, 8*fem, 27*fem, 0*fem),
                                              width: 70*fem,
                                              height: 70*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/image-31.png',
                                                fit: BoxFit.cover,
                                              ),
                                            ),
                                            Container(
                                              // image29LDE (39:119)
                                              width: 20*fem,
                                              height: 20*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/image-29.png',
                                                fit: BoxFit.cover,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        // namesyr (39:125)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 56*fem, 0*fem),
                                        child: Text(
                                          'name',
                                          style: SafeGoogleFont (
                                            'Itim',
                                            fontSize: 20*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.2*ffem/fem,
                                            color: Color(0xff000000),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogroupdoutDH2 (WodyLxkMqPhpXgr3PRdoUt)
                            width: 128*fem,
                            height: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // autogroupmdd29wN (WodydcwGbAkMCFuJ2FMdD2)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 35*fem),
                                  padding: EdgeInsets.fromLTRB(7*fem, 7*fem, 0*fem, 7*fem),
                                  width: double.infinity,
                                  decoration: BoxDecoration (
                                    color: Color(0xffffffff),
                                    borderRadius: BorderRadius.circular(10*fem),
                                  ),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // autogrouprint42k (Wodz8rbZCEgxTAhK4ERiNt)
                                        width: double.infinity,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // image281ig (39:112)
                                              margin: EdgeInsets.fromLTRB(0*fem, 3*fem, 31*fem, 0*fem),
                                              width: 70*fem,
                                              height: 70*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/image-28.png',
                                                fit: BoxFit.cover,
                                              ),
                                            ),
                                            Container(
                                              // image13LFA (39:105)
                                              width: 20*fem,
                                              height: 20*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/image-13.png',
                                                fit: BoxFit.cover,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        // namef2Y (39:126)
                                        margin: EdgeInsets.fromLTRB(9*fem, 0*fem, 0*fem, 0*fem),
                                        child: Text(
                                          'name',
                                          style: SafeGoogleFont (
                                            'Itim',
                                            fontSize: 20*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.2*ffem/fem,
                                            color: Color(0xff000000),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // autogroupqrycBma (WodzHMMQ93SayH7bDjQRYC)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 35*fem),
                                  padding: EdgeInsets.fromLTRB(9*fem, 6*fem, 0*fem, 13*fem),
                                  width: double.infinity,
                                  decoration: BoxDecoration (
                                    color: Color(0xffffffff),
                                    borderRadius: BorderRadius.circular(10*fem),
                                  ),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // autogroupqavnhV2 (WodzNw2S9nfKiwSx5BqAVn)
                                        width: double.infinity,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // image28TUC (39:114)
                                              margin: EdgeInsets.fromLTRB(0*fem, 2*fem, 29*fem, 0*fem),
                                              width: 70*fem,
                                              height: 66*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/image-28-mYt.png',
                                                fit: BoxFit.cover,
                                              ),
                                            ),
                                            Container(
                                              // image14P6x (39:106)
                                              width: 20*fem,
                                              height: 20*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/image-14-bFE.png',
                                                fit: BoxFit.cover,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        // nameKFW (39:127)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 48*fem, 0*fem),
                                        child: Text(
                                          'name',
                                          style: SafeGoogleFont (
                                            'Itim',
                                            fontSize: 20*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.2*ffem/fem,
                                            color: Color(0xff000000),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // autogroup75seEtG (WodzWRowh62m86XKAA75se)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 28*fem),
                                  padding: EdgeInsets.fromLTRB(9*fem, 7*fem, 0*fem, 9*fem),
                                  width: double.infinity,
                                  decoration: BoxDecoration (
                                    color: Color(0xffffffff),
                                    borderRadius: BorderRadius.circular(10*fem),
                                  ),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // autogrouppscqk5v (Wodzb6LqanUzMDTardPSCQ)
                                        width: double.infinity,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // image28JdE (39:115)
                                              margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 29*fem, 0*fem),
                                              width: 70*fem,
                                              height: 70*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/image-28-G8g.png',
                                                fit: BoxFit.cover,
                                              ),
                                            ),
                                            Container(
                                              // image15dvQ (39:107)
                                              width: 20*fem,
                                              height: 20*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/image-15-2h6.png',
                                                fit: BoxFit.cover,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        // nameNsz (39:128)
                                        margin: EdgeInsets.fromLTRB(8*fem, 0*fem, 0*fem, 0*fem),
                                        child: Text(
                                          'name',
                                          style: SafeGoogleFont (
                                            'Itim',
                                            fontSize: 20*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.2*ffem/fem,
                                            color: Color(0xff000000),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // autogroupa9cc7Kn (WodzjAwi7JACuG9jQQa9cc)
                                  padding: EdgeInsets.fromLTRB(9*fem, 7*fem, 0*fem, 7*fem),
                                  width: double.infinity,
                                  height: 111*fem,
                                  decoration: BoxDecoration (
                                    color: Color(0xffffffff),
                                    borderRadius: BorderRadius.circular(10*fem),
                                  ),
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // image282he (39:117)
                                        margin: EdgeInsets.fromLTRB(0*fem, 8*fem, 29*fem, 0*fem),
                                        width: 70*fem,
                                        height: 70*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/image-28-Pnx.png',
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                      Container(
                                        // image16A3A (39:108)
                                        width: 20*fem,
                                        height: 20*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/image-16-o6G.png',
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogroupkjdvT2G (Woe18AHQRwxcfD3nCakJdv)
                            padding: EdgeInsets.fromLTRB(35*fem, 133*fem, 1*fem, 133*fem),
                            width: 40*fem,
                            height: double.infinity,
                            child: Align(
                              // rectangle26ymJ (39:102)
                              alignment: Alignment.centerRight,
                              child: SizedBox(
                                width: double.infinity,
                                height: 68*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0xff000000),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}