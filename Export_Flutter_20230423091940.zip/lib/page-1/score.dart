import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // scoreZ36 (20:168)
        padding: EdgeInsets.fromLTRB(13*fem, 14*fem, 22*fem, 70*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          gradient: LinearGradient (
            begin: Alignment(0.397, -0.059),
            end: Alignment(0.633, 1.049),
            colors: <Color>[Color(0xff063f82), Color(0x9366c41d)],
            stops: <double>[0, 1],
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupmentbVa (Woe5Rcx5LJY8fhAS7Cment)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 9*fem),
              width: double.infinity,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    // image11j5z (20:170)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 260*fem, 0*fem),
                    width: 25*fem,
                    height: 25*fem,
                    child: Image.asset(
                      'assets/page-1/images/image-11-J8Y.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                  Container(
                    // image16eCx (20:201)
                    margin: EdgeInsets.fromLTRB(0*fem, 5*fem, 0*fem, 0*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 40*fem,
                        height: 40*fem,
                        child: Image.asset(
                          'assets/page-1/images/image-16.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // ellipse4M7N (20:177)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 175*fem, 0*fem),
              width: 100*fem,
              height: 100*fem,
              decoration: BoxDecoration (
                borderRadius: BorderRadius.circular(50*fem),
                image: DecorationImage (
                  fit: BoxFit.cover,
                  image: AssetImage (
                    'assets/page-1/images/ellipse-4-bg-QZv.png',
                  ),
                ),
              ),
            ),
            Container(
              // yourscore4Gg (20:175)
              margin: EdgeInsets.fromLTRB(9*fem, 0*fem, 0*fem, 7*fem),
              child: Text(
                'your score',
                style: SafeGoogleFont (
                  'Itim',
                  fontSize: 32*ffem,
                  fontWeight: FontWeight.w400,
                  height: 1.2*ffem/fem,
                  color: Color(0xffffffff),
                ),
              ),
            ),
            Container(
              // frame19mRz (20:178)
              margin: EdgeInsets.fromLTRB(100*fem, 0*fem, 92*fem, 52*fem),
              width: double.infinity,
              height: 134*fem,
              decoration: BoxDecoration (
                image: DecorationImage (
                  fit: BoxFit.cover,
                  image: AssetImage (
                    'assets/page-1/images/ellipse-6.png',
                  ),
                ),
              ),
              child: Stack(
                children: [
                  Positioned(
                    // ellipse7V76 (20:174)
                    left: 13*fem,
                    top: 12*fem,
                    child: Align(
                      child: SizedBox(
                        width: 107*fem,
                        height: 110*fem,
                        child: Image.asset(
                          'assets/page-1/images/ellipse-7.png',
                          width: 107*fem,
                          height: 110*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // ptsauE (20:183)
                    left: 37*fem,
                    top: 48*fem,
                    child: Align(
                      child: SizedBox(
                        width: 60*fem,
                        height: 39*fem,
                        child: Text(
                          '7pts',
                          style: SafeGoogleFont (
                            'Itim',
                            fontSize: 32*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.2*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // frame22Hoe (20:199)
              margin: EdgeInsets.fromLTRB(25*fem, 0*fem, 20*fem, 55.98*fem),
              width: double.infinity,
              height: 100*fem,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                borderRadius: BorderRadius.circular(10*fem),
              ),
              child: Stack(
                children: [
                  Positioned(
                    // correctC9v (20:187)
                    left: 40*fem,
                    top: 65*fem,
                    child: Align(
                      child: SizedBox(
                        width: 61*fem,
                        height: 20*fem,
                        child: Text(
                          '7 correct',
                          style: SafeGoogleFont (
                            'Itim',
                            fontSize: 16*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.2*ffem/fem,
                            color: Color(0xff0cd639),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // totalquestions20uKE (20:186)
                    left: 150*fem,
                    top: 20*fem,
                    child: Align(
                      child: SizedBox(
                        width: 125*fem,
                        height: 20*fem,
                        child: Text(
                          'total questions 20',
                          style: SafeGoogleFont (
                            'Itim',
                            fontSize: 16*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.2*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // line5awA (20:180)
                    left: 142*fem,
                    top: 20*fem,
                    child: Align(
                      child: SizedBox(
                        width: 1*fem,
                        height: 65*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // line66Pi (20:181)
                    left: 88*fem,
                    top: 52*fem,
                    child: Align(
                      child: SizedBox(
                        width: 107*fem,
                        height: 1*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // answeredRB6 (20:185)
                    left: 31*fem,
                    top: 20*fem,
                    child: Align(
                      child: SizedBox(
                        width: 87*fem,
                        height: 20*fem,
                        child: Text(
                          '10 answered',
                          style: SafeGoogleFont (
                            'Itim',
                            fontSize: 16*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.2*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // wrongiR6 (20:188)
                    left: 185*fem,
                    top: 65*fem,
                    child: Align(
                      child: SizedBox(
                        width: 55*fem,
                        height: 20*fem,
                        child: Text(
                          '3 wrong',
                          style: SafeGoogleFont (
                            'Itim',
                            fontSize: 16*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.2*ffem/fem,
                            color: Color(0xffea1010),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // frame211f6 (20:198)
              margin: EdgeInsets.fromLTRB(61*fem, 0*fem, 73*fem, 0*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupubglLhN (Woe5rmtq2tLHrNdxuXUBgL)
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Container(
                          // autogroupa85nVqA (Woe5xc4Su1Q5PGooXca85n)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 78*fem, 2*fem),
                          width: 71*fem,
                          height: 65.02*fem,
                          child: Stack(
                            children: [
                              Positioned(
                                // image13q8L (20:190)
                                left: 9.9820098877*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 50.04*fem,
                                    height: 50.04*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/image-13-Rep.png',
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // playagainkFJ (20:191)
                                left: 0*fem,
                                top: 45.0180664062*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 71*fem,
                                    height: 20*fem,
                                    child: TextButton(
                                      onPressed: () {},
                                      style: TextButton.styleFrom (
                                        padding: EdgeInsets.zero,
                                      ),
                                      child: Text(
                                        'play again',
                                        style: SafeGoogleFont (
                                          'Itim',
                                          fontSize: 16*ffem,
                                          fontWeight: FontWeight.w400,
                                          height: 1.2*ffem/fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // autogroupbhuuQak (Woe62Bnp6jrRu2TLE1bHUU)
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Container(
                                // image14NGg (20:193)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 2*fem),
                                width: 40*fem,
                                height: 40*fem,
                                child: Image.asset(
                                  'assets/page-1/images/image-14.png',
                                  fit: BoxFit.cover,
                                ),
                              ),
                              Text(
                                // shareJRE (20:194)
                                'share',
                                style: SafeGoogleFont (
                                  'Itim',
                                  fontSize: 16*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.2*ffem/fem,
                                  color: Color(0xff121212),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupbataqvx (Woe6CGLMSGJ2gyqJvrBaTa)
                    padding: EdgeInsets.fromLTRB(65*fem, 37*fem, 43*fem, 0*fem),
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // image15atY (20:196)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0*fem),
                          width: 50*fem,
                          height: 50*fem,
                          child: Image.asset(
                            'assets/page-1/images/image-15.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                        TextButton(
                          // leaderboardufv (20:197)
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Text(
                            'leaderboard',
                            style: SafeGoogleFont (
                              'Itim',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}