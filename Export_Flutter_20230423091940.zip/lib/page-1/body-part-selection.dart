import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // bodypartselectionUEk (53:2)
        width: double.infinity,
        decoration: BoxDecoration (
          gradient: LinearGradient (
            begin: Alignment(0.397, -0.059),
            end: Alignment(0.633, 1.049),
            colors: <Color>[Color(0xff063f82), Color(0x9366c41d)],
            stops: <double>[0, 1],
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Container(
              // autogroupxtfaXTv (Wodr5RMkez5xiFnLCfXtFa)
              padding: EdgeInsets.fromLTRB(8*fem, 16*fem, 8*fem, 30*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    // autogroupue2cEt8 (WodqXMSrQKE9HJrDnBUE2c)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 17*fem, 15*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // image14yKv (54:60)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 267*fem, 6*fem),
                          width: 30*fem,
                          height: 30*fem,
                          child: Image.asset(
                            'assets/page-1/images/image-14-3mA.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                        Container(
                          // image10Jd6 (53:3)
                          margin: EdgeInsets.fromLTRB(0*fem, 6*fem, 0*fem, 0*fem),
                          width: 30*fem,
                          height: 30*fem,
                          child: Image.asset(
                            'assets/page-1/images/image-10-YsA.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // ellipse4SjJ (53:4)
                    margin: EdgeInsets.fromLTRB(15*fem, 0*fem, 0*fem, 7*fem),
                    width: 100*fem,
                    height: 100*fem,
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(50*fem),
                      image: DecorationImage (
                        fit: BoxFit.cover,
                        image: AssetImage (
                          'assets/page-1/images/ellipse-4-bg-3sn.png',
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // patientnameZJ8 (53:6)
                    margin: EdgeInsets.fromLTRB(15*fem, 0*fem, 0*fem, 0*fem),
                    child: Text(
                      'patient name',
                      style: SafeGoogleFont (
                        'Itim',
                        fontSize: 20*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.2*ffem/fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                  Container(
                    // ageGyE (53:7)
                    margin: EdgeInsets.fromLTRB(15*fem, 0*fem, 0*fem, 7*fem),
                    child: Text(
                      'age',
                      style: SafeGoogleFont (
                        'Itim',
                        fontSize: 20*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.2*ffem/fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                  Container(
                    // recentlyplayedoCU (53:19)
                    margin: EdgeInsets.fromLTRB(14*fem, 0*fem, 0*fem, 0*fem),
                    child: Text(
                      'recently played',
                      style: SafeGoogleFont (
                        'Itim',
                        fontSize: 20*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.2*ffem/fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupj7ccKgc (WodqhmKAsg8USv1WBCJ7cC)
              width: 392*fem,
              height: 563*fem,
              child: Stack(
                children: [
                  Positioned(
                    // rectangle4248Q (54:43)
                    left: 0*fem,
                    top: 1*fem,
                    child: Align(
                      child: SizedBox(
                        width: 386*fem,
                        height: 562*fem,
                        child: Image.asset(
                          'assets/page-1/images/rectangle-42.png',
                          width: 386*fem,
                          height: 562*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle43mYc (54:44)
                    left: 0*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 392*fem,
                        height: 562*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(40*fem),
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // image42VUc (54:46)
                    left: 130*fem,
                    top: 119*fem,
                    child: Align(
                      child: SizedBox(
                        width: 100*fem,
                        height: 100*fem,
                        child: Image.asset(
                          'assets/page-1/images/image-42.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // headokC (54:47)
                    left: 160*fem,
                    top: 234*fem,
                    child: Align(
                      child: SizedBox(
                        width: 50*fem,
                        height: 29*fem,
                        child: Text(
                          'head\n',
                          style: SafeGoogleFont (
                            'Itim',
                            fontSize: 24*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.2*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // line4WPi (54:48)
                    left: 110*fem,
                    top: 119*fem,
                    child: ClipRect(
                      child: BackdropFilter(
                        filter: ImageFilter.blur (
                          sigmaX: 2*fem,
                          sigmaY: 2*fem,
                        ),
                        child: Align(
                          child: SizedBox(
                            width: 1*fem,
                            height: 163*fem,
                            child: Container(
                              decoration: BoxDecoration (
                                color: Color(0xff000000),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // line5bvx (54:52)
                    left: 256*fem,
                    top: 119*fem,
                    child: ClipRect(
                      child: BackdropFilter(
                        filter: ImageFilter.blur (
                          sigmaX: 2*fem,
                          sigmaY: 2*fem,
                        ),
                        child: Align(
                          child: SizedBox(
                            width: 1*fem,
                            height: 163*fem,
                            child: Container(
                              decoration: BoxDecoration (
                                color: Color(0xff000000),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // selectbodyparttotrainiEt (54:49)
                    left: 22*fem,
                    top: 26*fem,
                    child: Align(
                      child: SizedBox(
                        width: 247*fem,
                        height: 29*fem,
                        child: Text(
                          'select body part to train',
                          style: SafeGoogleFont (
                            'Itim',
                            fontSize: 24*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.2*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // image43QtQ (54:51)
                    left: 278*fem,
                    top: 142*fem,
                    child: Align(
                      child: SizedBox(
                        width: 70*fem,
                        height: 70*fem,
                        child: Image.asset(
                          'assets/page-1/images/image-43.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // shoulder95J (54:53)
                    left: 276*fem,
                    top: 233*fem,
                    child: Align(
                      child: SizedBox(
                        width: 75*fem,
                        height: 24*fem,
                        child: Text(
                          'shoulder',
                          style: SafeGoogleFont (
                            'Itim',
                            fontSize: 20*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.2*ffem/fem,
                            color: Color(0xb2000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // image443wN (54:55)
                    left: 22*fem,
                    top: 133*fem,
                    child: Align(
                      child: SizedBox(
                        width: 70*fem,
                        height: 70*fem,
                        child: Image.asset(
                          'assets/page-1/images/image-44.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // lowerlimbxoS (54:56)
                    left: 13*fem,
                    top: 233*fem,
                    child: Align(
                      child: SizedBox(
                        width: 90*fem,
                        height: 24*fem,
                        child: Text(
                          'lower limb',
                          style: SafeGoogleFont (
                            'Itim',
                            fontSize: 20*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.2*ffem/fem,
                            color: Color(0xb2000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // frame1757N (54:57)
                    left: 102*fem,
                    top: 330*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(42*fem, 0*fem, 42*fem, 0*fem),
                      width: 165*fem,
                      height: 41*fem,
                      decoration: BoxDecoration (
                        color: Color(0xff205a9e),
                        borderRadius: BorderRadius.circular(10*fem),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0x3f000000),
                            offset: Offset(0*fem, 4*fem),
                            blurRadius: 2*fem,
                          ),
                        ],
                      ),
                      child: Text(
                        'select',
                        style: SafeGoogleFont (
                          'Itim',
                          fontSize: 32*ffem,
                          fontWeight: FontWeight.w400,
                          height: 1.2*ffem/fem,
                          color: Color(0xffffffff),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}