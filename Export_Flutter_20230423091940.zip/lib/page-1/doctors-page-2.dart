import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // doctorspage2euv (39:77)
        padding: EdgeInsets.fromLTRB(13*fem, 15*fem, 21*fem, 41*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          gradient: LinearGradient (
            begin: Alignment(0.397, -0.059),
            end: Alignment(0.633, 1.049),
            colors: <Color>[Color(0xff063f82), Color(0x9366c41d)],
            stops: <double>[0, 1],
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              // autogroupr5vaV9r (Woe37X8rTW35R1G9oBR5Va)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 43*fem),
              width: double.infinity,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // image32zcQ (39:131)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 266*fem, 0*fem),
                    width: 30*fem,
                    height: 30*fem,
                    child: Image.asset(
                      'assets/page-1/images/image-32-uLL.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                  Container(
                    // image35iHW (39:157)
                    width: 30*fem,
                    height: 30*fem,
                    child: Image.asset(
                      'assets/page-1/images/image-35.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // ellipse6rPi (39:130)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 11*fem),
              width: 100*fem,
              height: 100*fem,
              decoration: BoxDecoration (
                borderRadius: BorderRadius.circular(50*fem),
                image: DecorationImage (
                  fit: BoxFit.cover,
                  image: AssetImage (
                    'assets/page-1/images/ellipse-6-bg.png',
                  ),
                ),
              ),
            ),
            Container(
              // autogroupfq24xhe (Woe3F6kZHG2CQaHLohFQ24)
              margin: EdgeInsets.fromLTRB(6*fem, 0*fem, 1*fem, 51*fem),
              width: double.infinity,
              height: 69*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogrouphhrygtY (Woe3R6TuLKr7c7iVazHHrY)
                    height: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // autogroupcpuadYt (Woe3a6CuytHqghojHkcPua)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 2*fem),
                          width: 49*fem,
                          height: 43*fem,
                          child: Stack(
                            children: [
                              Positioned(
                                // nameZBe (39:132)
                                left: 0*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 49*fem,
                                    height: 24*fem,
                                    child: Text(
                                      'name\n',
                                      style: SafeGoogleFont (
                                        'Itim',
                                        fontSize: 20*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.2*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // ageE2t (39:133)
                                left: 0*fem,
                                top: 19*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 31*fem,
                                    height: 24*fem,
                                    child: Text(
                                      'age',
                                      style: SafeGoogleFont (
                                        'Itim',
                                        fontSize: 20*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.2*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Text(
                          // medicalconditionKKE (39:134)
                          'medical condition',
                          style: SafeGoogleFont (
                            'Itim',
                            fontSize: 20*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.2*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroup8wpcFig (Woe3yaXn1HnM18NjdC8wpc)
                    padding: EdgeInsets.fromLTRB(22*fem, 0*fem, 0*fem, 0*fem),
                    height: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // line11nTi (39:137)
                          margin: EdgeInsets.fromLTRB(0*fem, 3*fem, 11*fem, 0*fem),
                          width: 1*fem,
                          height: 66*fem,
                          decoration: BoxDecoration (
                            color: Color(0xff000000),
                          ),
                        ),
                        Container(
                          // autogroupf984VN8 (Woe3fFiyaLSAUJQxXVF984)
                          margin: EdgeInsets.fromLTRB(0*fem, 2*fem, 13*fem, 0*fem),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                // heightRFn (39:138)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 5*fem),
                                child: Text(
                                  'height',
                                  style: SafeGoogleFont (
                                    'Itim',
                                    fontSize: 20*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.2*ffem/fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                              Text(
                                // weightKrx (39:139)
                                'weight',
                                style: SafeGoogleFont (
                                  'Itim',
                                  fontSize: 20*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.2*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // autogroupjdj8GnC (Woe3qzv5BXoE1ZMYcgJdJ8)
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // cmpoi (39:135)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 7*fem),
                                child: Text(
                                  '187 cm',
                                  style: SafeGoogleFont (
                                    'Itim',
                                    fontSize: 20*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.2*ffem/fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                              Text(
                                // kgkSU (39:136)
                                '83 kg',
                                style: SafeGoogleFont (
                                  'Itim',
                                  fontSize: 20*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.2*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // frame34hMi (54:95)
              margin: EdgeInsets.fromLTRB(15*fem, 0*fem, 7*fem, 51*fem),
              padding: EdgeInsets.fromLTRB(3*fem, 4*fem, 3*fem, 18*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                borderRadius: BorderRadius.circular(10*fem),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupdwvantx (Woe4xYtr7AbGqWwu5NDwVA)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4*fem, 23*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Container(
                          // lastweekLQg (39:145)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 194*fem, 0*fem),
                          child: Text(
                            'last week',
                            style: SafeGoogleFont (
                              'Itim',
                              fontSize: 20*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                        Container(
                          // image34FGk (39:147)
                          width: 20*fem,
                          height: 20*fem,
                          child: Image.asset(
                            'assets/page-1/images/image-34.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroup9tyjnGg (Woe55YhBwiGcgCMJd59TyJ)
                    margin: EdgeInsets.fromLTRB(27*fem, 0*fem, 24*fem, 0*fem),
                    width: double.infinity,
                    height: 70*fem,
                    child: Stack(
                      children: [
                        Positioned(
                          // squats100WTa (54:2)
                          left: 0*fem,
                          top: 5*fem,
                          child: Align(
                            child: SizedBox(
                              width: 72*fem,
                              height: 18*fem,
                              child: Text(
                                'squats 100',
                                style: SafeGoogleFont (
                                  'Itim',
                                  fontSize: 15*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.2*ffem/fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // line12QJ4 (39:150)
                          left: 119*fem,
                          top: 2*fem,
                          child: Align(
                            child: SizedBox(
                              width: 1*fem,
                              height: 58*fem,
                              child: Container(
                                decoration: BoxDecoration (
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // line13iZe (39:153)
                          left: 73*fem,
                          top: 35*fem,
                          child: Align(
                            child: SizedBox(
                              width: 94*fem,
                              height: 1*fem,
                              child: Container(
                                decoration: BoxDecoration (
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // propersquats80btL (39:154)
                          left: 138*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 109*fem,
                              height: 18*fem,
                              child: Text(
                                'proper squats 80',
                                style: SafeGoogleFont (
                                  'Itim',
                                  fontSize: 15*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.2*ffem/fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // badsquats20HWG (39:155)
                          left: 0*fem,
                          top: 46*fem,
                          child: Align(
                            child: SizedBox(
                              width: 91*fem,
                              height: 18*fem,
                              child: Text(
                                'bad squats 20',
                                style: SafeGoogleFont (
                                  'Itim',
                                  fontSize: 15*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.2*ffem/fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // image36zfa (39:160)
                          left: 167*fem,
                          top: 40*fem,
                          child: Align(
                            child: SizedBox(
                              width: 30*fem,
                              height: 30*fem,
                              child: Image.asset(
                                'assets/page-1/images/image-36.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // frame32j7N (54:90)
              margin: EdgeInsets.fromLTRB(30*fem, 0*fem, 41*fem, 0*fem),
              padding: EdgeInsets.fromLTRB(18*fem, 7*fem, 4*fem, 11*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                borderRadius: BorderRadius.circular(10*fem),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupuhkvpec (Woe4htecAQK8QraUbbuhKv)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // activityZcC (39:143)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 144*fem, 0*fem),
                          child: Text(
                            'activity ',
                            style: SafeGoogleFont (
                              'Itim',
                              fontSize: 20*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                        Container(
                          // image32gwi (39:146)
                          width: 20*fem,
                          height: 20*fem,
                          child: Image.asset(
                            'assets/page-1/images/image-32-bD2.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // image33qZi (39:141)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 33*fem, 0*fem),
                    width: 200*fem,
                    height: 200*fem,
                    child: Image.asset(
                      'assets/page-1/images/image-33.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}