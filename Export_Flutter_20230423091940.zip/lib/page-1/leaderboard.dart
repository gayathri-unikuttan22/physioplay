import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // leaderboardLAC (20:206)
        width: double.infinity,
        decoration: BoxDecoration (
          gradient: LinearGradient (
            begin: Alignment(-0.819, -0.343),
            end: Alignment(0.633, 1.049),
            colors: <Color>[Color(0xff063f82), Color(0x9366c41d)],
            stops: <double>[0, 1],
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Container(
              // autogroupj2sj232 (Woe75VMzxUeratBTgUj2sJ)
              padding: EdgeInsets.fromLTRB(11*fem, 7*fem, 8*fem, 0*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  TextButton(
                    // image17jy2 (39:26)
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Container(
                      width: 30*fem,
                      height: 30*fem,
                      child: Image.asset(
                        'assets/page-1/images/image-17-LVW.png',
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  Container(
                    // autogroupgy3251J (Woe6b1BTuYFPfgtsxPgY32)
                    margin: EdgeInsets.fromLTRB(17*fem, 0*fem, 0*fem, 0*fem),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // todayQJU (20:208)
                          margin: EdgeInsets.fromLTRB(0*fem, 3*fem, 9*fem, 0*fem),
                          child: Text(
                            'today',
                            style: SafeGoogleFont (
                              'Itim',
                              fontSize: 36*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2*ffem/fem,
                              color: Color(0xff0f0e0e),
                            ),
                          ),
                        ),
                        Container(
                          // line7Ht4 (20:210)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 21*fem, 0*fem),
                          width: 1*fem,
                          height: 55*fem,
                          decoration: BoxDecoration (
                            color: Color(0xff000000),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0x3f000000),
                                offset: Offset(0*fem, 4*fem),
                                blurRadius: 2*fem,
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // thisweekCEL (20:209)
                          margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 21*fem, 0*fem),
                          child: Text(
                            'this week\n',
                            style: SafeGoogleFont (
                              'Itim',
                              fontSize: 20*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2*ffem/fem,
                              color: Color(0xff0e0d0d),
                            ),
                          ),
                        ),
                        Container(
                          // line8WVv (20:211)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10*fem, 0*fem),
                          width: 1*fem,
                          height: 55*fem,
                          decoration: BoxDecoration (
                            color: Color(0xff000000),
                          ),
                        ),
                        Container(
                          // lastmonthqo6 (20:212)
                          margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 0*fem),
                          child: Text(
                            'last month',
                            style: SafeGoogleFont (
                              'Itim',
                              fontSize: 20*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2*ffem/fem,
                              color: Color(0xff100f0f),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupcnxxLjr (Woe6pQxnbRJJCA5uazcnxx)
                    margin: EdgeInsets.fromLTRB(44*fem, 0*fem, 49*fem, 0*fem),
                    width: double.infinity,
                    height: 292*fem,
                    child: Stack(
                      children: [
                        Positioned(
                          // ptssUt (39:3)
                          left: 4*fem,
                          top: 185*fem,
                          child: Align(
                            child: SizedBox(
                              width: 61*fem,
                              height: 24*fem,
                              child: Text(
                                '350pts',
                                style: SafeGoogleFont (
                                  'Itim',
                                  fontSize: 20*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.2*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // ellipse4y28 (20:217)
                          left: 0*fem,
                          top: 84*fem,
                          child: Align(
                            child: SizedBox(
                              width: 70*fem,
                              height: 76*fem,
                              child: Image.asset(
                                'assets/page-1/images/ellipse-4-Kig.png',
                                width: 70*fem,
                                height: 76*fem,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // image18Uja (20:219)
                          left: 87*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 70*fem,
                              height: 70*fem,
                              child: Image.asset(
                                'assets/page-1/images/image-18-sm2.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // image19Btt (20:221)
                          left: 178*fem,
                          top: 52*fem,
                          child: Align(
                            child: SizedBox(
                              width: 70*fem,
                              height: 70*fem,
                              child: Image.asset(
                                'assets/page-1/images/image-19.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // ptsiP2 (35:21)
                          left: 94*fem,
                          top: 98*fem,
                          child: Align(
                            child: SizedBox(
                              width: 64*fem,
                              height: 24*fem,
                              child: Text(
                                '400pts',
                                style: SafeGoogleFont (
                                  'Itim',
                                  fontSize: 20*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.2*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // ptsdVz (39:2)
                          left: 183*fem,
                          top: 148*fem,
                          child: Align(
                            child: SizedBox(
                              width: 59*fem,
                              height: 24*fem,
                              child: Text(
                                '375pts',
                                style: SafeGoogleFont (
                                  'Itim',
                                  fontSize: 20*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.2*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // image17LQQ (20:216)
                          left: 0*fem,
                          top: 87*fem,
                          child: Align(
                            child: SizedBox(
                              width: 247*fem,
                              height: 205*fem,
                              child: Image.asset(
                                'assets/page-1/images/image-17.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // frame244bJ (39:87)
              width: 409*fem,
              height: 536*fem,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                borderRadius: BorderRadius.circular(40*fem),
              ),
              child: Stack(
                children: [
                  Positioned(
                    // line9apY (39:89)
                    left: 352*fem,
                    top: 55*fem,
                    child: Align(
                      child: SizedBox(
                        width: 1*fem,
                        height: 239*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            color: Color(0x7f000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle26huA (39:90)
                    left: 348*fem,
                    top: 140*fem,
                    child: Align(
                      child: SizedBox(
                        width: 4*fem,
                        height: 68*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // autogroupwpatcmE (Woe7ktQ2BXekEAJHLqwpAt)
                    left: 15*fem,
                    top: 55*fem,
                    child: Container(
                      width: 326*fem,
                      height: 338*fem,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // frame27Yet (49:189)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 23*fem),
                            width: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // autogroupbtpxtCx (Woe8GxNFdBkBRCYZcGbtpx)
                                  padding: EdgeInsets.fromLTRB(2*fem, 3*fem, 38*fem, 2*fem),
                                  width: double.infinity,
                                  decoration: BoxDecoration (
                                    color: Color(0xff78b6ff),
                                    borderRadius: BorderRadius.circular(10*fem),
                                  ),
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // image26Bxk (39:24)
                                        margin: EdgeInsets.fromLTRB(0*fem, 2*fem, 7*fem, 0*fem),
                                        width: 20*fem,
                                        height: 20*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/image-26.png',
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                      Container(
                                        // image20Wk8 (39:5)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                                        width: 50*fem,
                                        height: 50*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/image-20.png',
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                      Container(
                                        // namedZr (39:12)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 81*fem, 4*fem),
                                        child: Text(
                                          'name',
                                          style: SafeGoogleFont (
                                            'Itim',
                                            fontSize: 20*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.2*ffem/fem,
                                            color: Color(0xff000000),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // ptsXv8 (39:16)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                        child: Text(
                                          '300pts',
                                          style: SafeGoogleFont (
                                            'Itim',
                                            fontSize: 20*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.2*ffem/fem,
                                            color: Color(0xff000000),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(
                                  height: 18*fem,
                                ),
                                Container(
                                  // autogroupnanuREp (Woe8UhXgdtVS5Qq4mzNAnU)
                                  padding: EdgeInsets.fromLTRB(2*fem, 5*fem, 43*fem, 0*fem),
                                  width: double.infinity,
                                  decoration: BoxDecoration (
                                    color: Color(0xff78b6ff),
                                    borderRadius: BorderRadius.circular(10*fem),
                                  ),
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // image277tL (39:25)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 7*fem, 6*fem),
                                        width: 20*fem,
                                        height: 20*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/image-27.png',
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                      Container(
                                        // image21r5E (39:7)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 15*fem, 0*fem),
                                        width: 50*fem,
                                        height: 50*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/image-21.png',
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                      Container(
                                        // nameyvY (39:13)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 81*fem, 6*fem),
                                        child: Text(
                                          'name',
                                          style: SafeGoogleFont (
                                            'Itim',
                                            fontSize: 20*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.2*ffem/fem,
                                            color: Color(0xff000000),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // ptshrY (39:17)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 6*fem),
                                        child: Text(
                                          '299pts\n',
                                          style: SafeGoogleFont (
                                            'Itim',
                                            fontSize: 20*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.2*ffem/fem,
                                            color: Color(0xff000000),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(
                                  height: 18*fem,
                                ),
                                Container(
                                  // autogroupjrfjpAU (Woe8fH4PgAd8Rqt126JrfJ)
                                  padding: EdgeInsets.fromLTRB(2*fem, 5*fem, 40*fem, 0*fem),
                                  width: double.infinity,
                                  decoration: BoxDecoration (
                                    color: Color(0xff78b6ff),
                                    borderRadius: BorderRadius.circular(10*fem),
                                  ),
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // image25jYL (39:23)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 7*fem, 8*fem),
                                        width: 20*fem,
                                        height: 20*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/image-25.png',
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                      Container(
                                        // image22G2U (39:9)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 14*fem, 0*fem),
                                        width: 50*fem,
                                        height: 50*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/image-22.png',
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                      Container(
                                        // nameu5S (39:14)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 83*fem, 4*fem),
                                        child: Text(
                                          'name',
                                          style: SafeGoogleFont (
                                            'Itim',
                                            fontSize: 20*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.2*ffem/fem,
                                            color: Color(0xff000000),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // ptsoAp (39:18)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                        child: Text(
                                          '250pts',
                                          style: SafeGoogleFont (
                                            'Itim',
                                            fontSize: 20*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.2*ffem/fem,
                                            color: Color(0xff000000),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(
                                  height: 18*fem,
                                ),
                                Container(
                                  // autogroup5zzi6vc (Woe8pByD3GTAv22QoK5ZZi)
                                  padding: EdgeInsets.fromLTRB(2*fem, 2*fem, 41*fem, 3*fem),
                                  width: double.infinity,
                                  decoration: BoxDecoration (
                                    color: Color(0xff78b6ff),
                                    borderRadius: BorderRadius.circular(10*fem),
                                  ),
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // image242ZN (39:21)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 7*fem, 0*fem),
                                        width: 20*fem,
                                        height: 20*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/image-24.png',
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                      Container(
                                        // image23mG4 (39:11)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 13*fem, 0*fem),
                                        width: 50*fem,
                                        height: 50*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/image-23.png',
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                      Container(
                                        // nameu7N (39:15)
                                        margin: EdgeInsets.fromLTRB(0*fem, 4*fem, 83*fem, 0*fem),
                                        child: Text(
                                          'name',
                                          style: SafeGoogleFont (
                                            'Itim',
                                            fontSize: 20*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.2*ffem/fem,
                                            color: Color(0xff000000),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // pts2St (39:19)
                                        margin: EdgeInsets.fromLTRB(0*fem, 4*fem, 0*fem, 0*fem),
                                        child: Text(
                                          '250pts',
                                          style: SafeGoogleFont (
                                            'Itim',
                                            fontSize: 20*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.2*ffem/fem,
                                            color: Color(0xff000000),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // frame16A3J (35:17)
                            margin: EdgeInsets.fromLTRB(80*fem, 0*fem, 81*fem, 0*fem),
                            width: double.infinity,
                            height: 41*fem,
                            decoration: BoxDecoration (
                              color: Color(0xff205a9e),
                              borderRadius: BorderRadius.circular(10*fem),
                              boxShadow: [
                                BoxShadow(
                                  color: Color(0x3f000000),
                                  offset: Offset(0*fem, 4*fem),
                                  blurRadius: 2*fem,
                                ),
                              ],
                            ),
                            child: Center(
                              child: Text(
                                'continue',
                                style: SafeGoogleFont (
                                  'Itim',
                                  fontSize: 32*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.2*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}