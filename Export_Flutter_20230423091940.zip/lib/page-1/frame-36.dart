import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 30;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // frame36vMn (54:118)
        width: double.infinity,
        height: 141*fem,
        child: Stack(
          children: [
            Positioned(
              // rectangle45GgY (54:117)
              left: 8*fem,
              top: 0*fem,
              child: Align(
                child: SizedBox(
                  width: 22*fem,
                  height: 141*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle44oAg (54:116)
              left: 0*fem,
              top: 0*fem,
              child: Align(
                child: SizedBox(
                  width: 30*fem,
                  height: 141*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(10*fem),
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // h6Qg (54:132)
              left: 15*fem,
              top: 4*fem,
              child: Align(
                child: SizedBox(
                  width: 11*fem,
                  height: 24*fem,
                  child: Text(
                    'h',
                    style: SafeGoogleFont (
                      'Itim',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}