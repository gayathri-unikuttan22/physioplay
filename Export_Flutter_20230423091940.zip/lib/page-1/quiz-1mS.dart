import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // quizwB6 (39:28)
        width: double.infinity,
        height: 800*fem,
        decoration: BoxDecoration (
          gradient: LinearGradient (
            begin: Alignment(0, -1),
            end: Alignment(1, 1),
            colors: <Color>[Color(0xff063f81), Color(0xdd66c31d)],
            stops: <double>[0.419, 0.994],
          ),
        ),
        child: Stack(
          children: [
            Positioned(
              // image28HeG (39:72)
              left: 130*fem,
              top: 300*fem,
              child: Align(
                child: SizedBox(
                  width: 100*fem,
                  height: 100*fem,
                  child: TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Image.asset(
                      'assets/page-1/images/image-28-h3E.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // quisiobex (44:176)
              left: 125*fem,
              top: 469*fem,
              child: Align(
                child: SizedBox(
                  width: 110*fem,
                  height: 58*fem,
                  child: Text(
                    'QUISIO',
                    style: SafeGoogleFont (
                      'Palanquin Dark',
                      fontSize: 32*ffem,
                      fontWeight: FontWeight.w700,
                      height: 1.81*ffem/fem,
                      color: Color(0xff0f0e0e),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // frame26JJU (44:184)
              left: 87*fem,
              top: 273*fem,
              child: Align(
                child: SizedBox(
                  width: 186*fem,
                  height: 255*fem,
                  child: Image.asset(
                    'assets/page-1/images/frame-26.png',
                    width: 186*fem,
                    height: 255*fem,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}